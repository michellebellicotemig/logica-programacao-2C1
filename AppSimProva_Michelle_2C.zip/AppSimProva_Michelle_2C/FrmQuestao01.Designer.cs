﻿namespace AppSimProva_Michelle_2C
{
    partial class FrmQuestao01
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmQuestao01));
            this.pnlTitulo = new System.Windows.Forms.Panel();
            this.lblTitulo = new System.Windows.Forms.Label();
            this.pnlProdutos = new System.Windows.Forms.Panel();
            this.txtPreco03 = new System.Windows.Forms.TextBox();
            this.txtPreco02 = new System.Windows.Forms.TextBox();
            this.txtPreco01 = new System.Windows.Forms.TextBox();
            this.lblPreco03 = new System.Windows.Forms.Label();
            this.lblPreco02 = new System.Windows.Forms.Label();
            this.lblPreco01 = new System.Windows.Forms.Label();
            this.txtJogo03 = new System.Windows.Forms.TextBox();
            this.lblJogo03 = new System.Windows.Forms.Label();
            this.txtJogo02 = new System.Windows.Forms.TextBox();
            this.lblJogo02 = new System.Windows.Forms.Label();
            this.txtJogo01 = new System.Windows.Forms.TextBox();
            this.lblJogo01 = new System.Windows.Forms.Label();
            this.pnlResultados = new System.Windows.Forms.Panel();
            this.lblResult5Parc = new System.Windows.Forms.Label();
            this.lbl5Parcelas = new System.Windows.Forms.Label();
            this.lblResult4Parc = new System.Windows.Forms.Label();
            this.lblResult3Parc = new System.Windows.Forms.Label();
            this.lblResult2Parc = new System.Windows.Forms.Label();
            this.lblResult1Parc = new System.Windows.Forms.Label();
            this.lbl4Parcelas = new System.Windows.Forms.Label();
            this.lbl3Parcelas = new System.Windows.Forms.Label();
            this.lbl2Parcelas = new System.Windows.Forms.Label();
            this.lbl1Parcela = new System.Windows.Forms.Label();
            this.btnCalcular = new System.Windows.Forms.Button();
            this.pnlTitulo.SuspendLayout();
            this.pnlProdutos.SuspendLayout();
            this.pnlResultados.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlTitulo
            // 
            this.pnlTitulo.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(155)))), ((int)(((byte)(93)))), ((int)(((byte)(229)))));
            this.pnlTitulo.Controls.Add(this.lblTitulo);
            this.pnlTitulo.Location = new System.Drawing.Point(-28, -8);
            this.pnlTitulo.Name = "pnlTitulo";
            this.pnlTitulo.Size = new System.Drawing.Size(682, 106);
            this.pnlTitulo.TabIndex = 0;
            // 
            // lblTitulo
            // 
            this.lblTitulo.AutoSize = true;
            this.lblTitulo.Font = new System.Drawing.Font("Arial Black", 36F, System.Drawing.FontStyle.Bold);
            this.lblTitulo.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.lblTitulo.Location = new System.Drawing.Point(129, 26);
            this.lblTitulo.Name = "lblTitulo";
            this.lblTitulo.Size = new System.Drawing.Size(464, 68);
            this.lblTitulo.TabIndex = 0;
            this.lblTitulo.Text = "LOJA DE GAMES";
            // 
            // pnlProdutos
            // 
            this.pnlProdutos.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(187)))), ((int)(((byte)(249)))));
            this.pnlProdutos.Controls.Add(this.txtPreco03);
            this.pnlProdutos.Controls.Add(this.txtPreco02);
            this.pnlProdutos.Controls.Add(this.txtPreco01);
            this.pnlProdutos.Controls.Add(this.lblPreco03);
            this.pnlProdutos.Controls.Add(this.lblPreco02);
            this.pnlProdutos.Controls.Add(this.lblPreco01);
            this.pnlProdutos.Controls.Add(this.txtJogo03);
            this.pnlProdutos.Controls.Add(this.lblJogo03);
            this.pnlProdutos.Controls.Add(this.txtJogo02);
            this.pnlProdutos.Controls.Add(this.lblJogo02);
            this.pnlProdutos.Controls.Add(this.txtJogo01);
            this.pnlProdutos.Controls.Add(this.lblJogo01);
            this.pnlProdutos.Location = new System.Drawing.Point(12, 112);
            this.pnlProdutos.Name = "pnlProdutos";
            this.pnlProdutos.Size = new System.Drawing.Size(377, 148);
            this.pnlProdutos.TabIndex = 2;
            // 
            // txtPreco03
            // 
            this.txtPreco03.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(187)))), ((int)(((byte)(249)))));
            this.txtPreco03.Font = new System.Drawing.Font("Arial Black", 10F, System.Drawing.FontStyle.Bold);
            this.txtPreco03.ForeColor = System.Drawing.SystemColors.Menu;
            this.txtPreco03.Location = new System.Drawing.Point(269, 97);
            this.txtPreco03.Name = "txtPreco03";
            this.txtPreco03.Size = new System.Drawing.Size(85, 26);
            this.txtPreco03.TabIndex = 14;
            // 
            // txtPreco02
            // 
            this.txtPreco02.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(187)))), ((int)(((byte)(249)))));
            this.txtPreco02.Font = new System.Drawing.Font("Arial Black", 10F, System.Drawing.FontStyle.Bold);
            this.txtPreco02.ForeColor = System.Drawing.SystemColors.Menu;
            this.txtPreco02.Location = new System.Drawing.Point(269, 55);
            this.txtPreco02.Name = "txtPreco02";
            this.txtPreco02.Size = new System.Drawing.Size(85, 26);
            this.txtPreco02.TabIndex = 13;
            // 
            // txtPreco01
            // 
            this.txtPreco01.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(187)))), ((int)(((byte)(249)))));
            this.txtPreco01.Font = new System.Drawing.Font("Arial Black", 10F, System.Drawing.FontStyle.Bold);
            this.txtPreco01.ForeColor = System.Drawing.SystemColors.Menu;
            this.txtPreco01.Location = new System.Drawing.Point(269, 14);
            this.txtPreco01.Name = "txtPreco01";
            this.txtPreco01.Size = new System.Drawing.Size(85, 26);
            this.txtPreco01.TabIndex = 12;
            // 
            // lblPreco03
            // 
            this.lblPreco03.AutoSize = true;
            this.lblPreco03.Font = new System.Drawing.Font("Arial Black", 10F, System.Drawing.FontStyle.Bold);
            this.lblPreco03.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.lblPreco03.Location = new System.Drawing.Point(188, 100);
            this.lblPreco03.Name = "lblPreco03";
            this.lblPreco03.Size = new System.Drawing.Size(75, 19);
            this.lblPreco03.TabIndex = 11;
            this.lblPreco03.Text = "Preço 03";
            // 
            // lblPreco02
            // 
            this.lblPreco02.AutoSize = true;
            this.lblPreco02.Font = new System.Drawing.Font("Arial Black", 10F, System.Drawing.FontStyle.Bold);
            this.lblPreco02.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.lblPreco02.Location = new System.Drawing.Point(188, 58);
            this.lblPreco02.Name = "lblPreco02";
            this.lblPreco02.Size = new System.Drawing.Size(75, 19);
            this.lblPreco02.TabIndex = 9;
            this.lblPreco02.Text = "Preço 02";
            // 
            // lblPreco01
            // 
            this.lblPreco01.AutoSize = true;
            this.lblPreco01.Font = new System.Drawing.Font("Arial Black", 10F, System.Drawing.FontStyle.Bold);
            this.lblPreco01.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.lblPreco01.Location = new System.Drawing.Point(188, 17);
            this.lblPreco01.Name = "lblPreco01";
            this.lblPreco01.Size = new System.Drawing.Size(75, 19);
            this.lblPreco01.TabIndex = 7;
            this.lblPreco01.Text = "Preço 01";
            // 
            // txtJogo03
            // 
            this.txtJogo03.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(187)))), ((int)(((byte)(249)))));
            this.txtJogo03.Font = new System.Drawing.Font("Arial Black", 10F, System.Drawing.FontStyle.Bold);
            this.txtJogo03.ForeColor = System.Drawing.SystemColors.Menu;
            this.txtJogo03.Location = new System.Drawing.Point(88, 97);
            this.txtJogo03.Name = "txtJogo03";
            this.txtJogo03.Size = new System.Drawing.Size(85, 26);
            this.txtJogo03.TabIndex = 6;
            // 
            // lblJogo03
            // 
            this.lblJogo03.AutoSize = true;
            this.lblJogo03.Font = new System.Drawing.Font("Arial Black", 10F, System.Drawing.FontStyle.Bold);
            this.lblJogo03.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.lblJogo03.Location = new System.Drawing.Point(14, 100);
            this.lblJogo03.Name = "lblJogo03";
            this.lblJogo03.Size = new System.Drawing.Size(68, 19);
            this.lblJogo03.TabIndex = 5;
            this.lblJogo03.Text = "Jogo 03";
            // 
            // txtJogo02
            // 
            this.txtJogo02.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(187)))), ((int)(((byte)(249)))));
            this.txtJogo02.Font = new System.Drawing.Font("Arial Black", 10F, System.Drawing.FontStyle.Bold);
            this.txtJogo02.ForeColor = System.Drawing.SystemColors.Menu;
            this.txtJogo02.Location = new System.Drawing.Point(88, 55);
            this.txtJogo02.Name = "txtJogo02";
            this.txtJogo02.Size = new System.Drawing.Size(85, 26);
            this.txtJogo02.TabIndex = 4;
            // 
            // lblJogo02
            // 
            this.lblJogo02.AutoSize = true;
            this.lblJogo02.Font = new System.Drawing.Font("Arial Black", 10F, System.Drawing.FontStyle.Bold);
            this.lblJogo02.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.lblJogo02.Location = new System.Drawing.Point(14, 58);
            this.lblJogo02.Name = "lblJogo02";
            this.lblJogo02.Size = new System.Drawing.Size(68, 19);
            this.lblJogo02.TabIndex = 3;
            this.lblJogo02.Text = "Jogo 02";
            // 
            // txtJogo01
            // 
            this.txtJogo01.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(187)))), ((int)(((byte)(249)))));
            this.txtJogo01.Font = new System.Drawing.Font("Arial Black", 10F, System.Drawing.FontStyle.Bold);
            this.txtJogo01.ForeColor = System.Drawing.SystemColors.Menu;
            this.txtJogo01.Location = new System.Drawing.Point(88, 14);
            this.txtJogo01.Name = "txtJogo01";
            this.txtJogo01.Size = new System.Drawing.Size(85, 26);
            this.txtJogo01.TabIndex = 2;
            // 
            // lblJogo01
            // 
            this.lblJogo01.AutoSize = true;
            this.lblJogo01.Font = new System.Drawing.Font("Arial Black", 10F, System.Drawing.FontStyle.Bold);
            this.lblJogo01.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.lblJogo01.Location = new System.Drawing.Point(14, 17);
            this.lblJogo01.Name = "lblJogo01";
            this.lblJogo01.Size = new System.Drawing.Size(68, 19);
            this.lblJogo01.TabIndex = 1;
            this.lblJogo01.Text = "Jogo 01";
            // 
            // pnlResultados
            // 
            this.pnlResultados.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(245)))), ((int)(((byte)(212)))));
            this.pnlResultados.Controls.Add(this.lblResult5Parc);
            this.pnlResultados.Controls.Add(this.lbl5Parcelas);
            this.pnlResultados.Controls.Add(this.lblResult4Parc);
            this.pnlResultados.Controls.Add(this.lblResult3Parc);
            this.pnlResultados.Controls.Add(this.lblResult2Parc);
            this.pnlResultados.Controls.Add(this.lblResult1Parc);
            this.pnlResultados.Controls.Add(this.lbl4Parcelas);
            this.pnlResultados.Controls.Add(this.lbl3Parcelas);
            this.pnlResultados.Controls.Add(this.lbl2Parcelas);
            this.pnlResultados.Controls.Add(this.lbl1Parcela);
            this.pnlResultados.Location = new System.Drawing.Point(384, 112);
            this.pnlResultados.Name = "pnlResultados";
            this.pnlResultados.Size = new System.Drawing.Size(250, 148);
            this.pnlResultados.TabIndex = 1;
            // 
            // lblResult5Parc
            // 
            this.lblResult5Parc.AutoSize = true;
            this.lblResult5Parc.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblResult5Parc.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.lblResult5Parc.Location = new System.Drawing.Point(158, 120);
            this.lblResult5Parc.Name = "lblResult5Parc";
            this.lblResult5Parc.Size = new System.Drawing.Size(13, 20);
            this.lblResult5Parc.TabIndex = 22;
            this.lblResult5Parc.Text = "-";
            // 
            // lbl5Parcelas
            // 
            this.lbl5Parcelas.AutoSize = true;
            this.lbl5Parcelas.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl5Parcelas.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.lbl5Parcelas.Location = new System.Drawing.Point(41, 120);
            this.lbl5Parcelas.Name = "lbl5Parcelas";
            this.lbl5Parcelas.Size = new System.Drawing.Size(95, 20);
            this.lbl5Parcelas.TabIndex = 21;
            this.lbl5Parcelas.Text = "5 parcelas de ";
            // 
            // lblResult4Parc
            // 
            this.lblResult4Parc.AutoSize = true;
            this.lblResult4Parc.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblResult4Parc.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.lblResult4Parc.Location = new System.Drawing.Point(159, 94);
            this.lblResult4Parc.Name = "lblResult4Parc";
            this.lblResult4Parc.Size = new System.Drawing.Size(13, 20);
            this.lblResult4Parc.TabIndex = 20;
            this.lblResult4Parc.Text = "-";
            // 
            // lblResult3Parc
            // 
            this.lblResult3Parc.AutoSize = true;
            this.lblResult3Parc.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblResult3Parc.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.lblResult3Parc.Location = new System.Drawing.Point(159, 63);
            this.lblResult3Parc.Name = "lblResult3Parc";
            this.lblResult3Parc.Size = new System.Drawing.Size(13, 20);
            this.lblResult3Parc.TabIndex = 19;
            this.lblResult3Parc.Text = "-";
            // 
            // lblResult2Parc
            // 
            this.lblResult2Parc.AutoSize = true;
            this.lblResult2Parc.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblResult2Parc.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.lblResult2Parc.Location = new System.Drawing.Point(159, 32);
            this.lblResult2Parc.Name = "lblResult2Parc";
            this.lblResult2Parc.Size = new System.Drawing.Size(13, 20);
            this.lblResult2Parc.TabIndex = 18;
            this.lblResult2Parc.Text = "-";
            // 
            // lblResult1Parc
            // 
            this.lblResult1Parc.AutoSize = true;
            this.lblResult1Parc.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblResult1Parc.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.lblResult1Parc.Location = new System.Drawing.Point(159, 5);
            this.lblResult1Parc.Name = "lblResult1Parc";
            this.lblResult1Parc.Size = new System.Drawing.Size(13, 20);
            this.lblResult1Parc.TabIndex = 17;
            this.lblResult1Parc.Text = "-";
            // 
            // lbl4Parcelas
            // 
            this.lbl4Parcelas.AutoSize = true;
            this.lbl4Parcelas.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl4Parcelas.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.lbl4Parcelas.Location = new System.Drawing.Point(41, 92);
            this.lbl4Parcelas.Name = "lbl4Parcelas";
            this.lbl4Parcelas.Size = new System.Drawing.Size(95, 20);
            this.lbl4Parcelas.TabIndex = 16;
            this.lbl4Parcelas.Text = "4 parcelas de ";
            // 
            // lbl3Parcelas
            // 
            this.lbl3Parcelas.AutoSize = true;
            this.lbl3Parcelas.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl3Parcelas.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.lbl3Parcelas.Location = new System.Drawing.Point(41, 62);
            this.lbl3Parcelas.Name = "lbl3Parcelas";
            this.lbl3Parcelas.Size = new System.Drawing.Size(95, 20);
            this.lbl3Parcelas.TabIndex = 15;
            this.lbl3Parcelas.Text = "3 parcelas de ";
            // 
            // lbl2Parcelas
            // 
            this.lbl2Parcelas.AutoSize = true;
            this.lbl2Parcelas.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl2Parcelas.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.lbl2Parcelas.Location = new System.Drawing.Point(42, 32);
            this.lbl2Parcelas.Name = "lbl2Parcelas";
            this.lbl2Parcelas.Size = new System.Drawing.Size(95, 20);
            this.lbl2Parcelas.TabIndex = 14;
            this.lbl2Parcelas.Text = "2 parcelas de ";
            // 
            // lbl1Parcela
            // 
            this.lbl1Parcela.AutoSize = true;
            this.lbl1Parcela.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl1Parcela.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.lbl1Parcela.Location = new System.Drawing.Point(41, 4);
            this.lbl1Parcela.Name = "lbl1Parcela";
            this.lbl1Parcela.Size = new System.Drawing.Size(88, 20);
            this.lbl1Parcela.TabIndex = 13;
            this.lbl1Parcela.Text = "1 parcela de ";
            // 
            // btnCalcular
            // 
            this.btnCalcular.BackColor = System.Drawing.Color.White;
            this.btnCalcular.Font = new System.Drawing.Font("Arial Black", 16F, System.Drawing.FontStyle.Bold);
            this.btnCalcular.Location = new System.Drawing.Point(12, 266);
            this.btnCalcular.Name = "btnCalcular";
            this.btnCalcular.Size = new System.Drawing.Size(622, 81);
            this.btnCalcular.TabIndex = 3;
            this.btnCalcular.Text = "CALCULAR";
            this.btnCalcular.UseVisualStyleBackColor = false;
            this.btnCalcular.Click += new System.EventHandler(this.btnCalcular_Click);
            // 
            // FrmQuestao01
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(241)))), ((int)(((byte)(91)))), ((int)(((byte)(181)))));
            this.ClientSize = new System.Drawing.Size(646, 357);
            this.Controls.Add(this.btnCalcular);
            this.Controls.Add(this.pnlResultados);
            this.Controls.Add(this.pnlProdutos);
            this.Controls.Add(this.pnlTitulo);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "FrmQuestao01";
            this.Text = "Loja de Games";
            this.pnlTitulo.ResumeLayout(false);
            this.pnlTitulo.PerformLayout();
            this.pnlProdutos.ResumeLayout(false);
            this.pnlProdutos.PerformLayout();
            this.pnlResultados.ResumeLayout(false);
            this.pnlResultados.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnlTitulo;
        private System.Windows.Forms.Label lblTitulo;
        private System.Windows.Forms.Panel pnlProdutos;
        private System.Windows.Forms.Label lblPreco03;
        private System.Windows.Forms.Label lblPreco02;
        private System.Windows.Forms.Label lblPreco01;
        private System.Windows.Forms.TextBox txtJogo03;
        private System.Windows.Forms.Label lblJogo03;
        private System.Windows.Forms.TextBox txtJogo02;
        private System.Windows.Forms.Label lblJogo02;
        private System.Windows.Forms.TextBox txtJogo01;
        private System.Windows.Forms.Label lblJogo01;
        private System.Windows.Forms.Panel pnlResultados;
        private System.Windows.Forms.Button btnCalcular;
        private System.Windows.Forms.Label lbl1Parcela;
        private System.Windows.Forms.TextBox txtPreco03;
        private System.Windows.Forms.TextBox txtPreco02;
        private System.Windows.Forms.TextBox txtPreco01;
        private System.Windows.Forms.Label lblResult4Parc;
        private System.Windows.Forms.Label lblResult3Parc;
        private System.Windows.Forms.Label lblResult2Parc;
        private System.Windows.Forms.Label lblResult1Parc;
        private System.Windows.Forms.Label lbl4Parcelas;
        private System.Windows.Forms.Label lbl3Parcelas;
        private System.Windows.Forms.Label lbl2Parcelas;
        private System.Windows.Forms.Label lblResult5Parc;
        private System.Windows.Forms.Label lbl5Parcelas;
    }
}

